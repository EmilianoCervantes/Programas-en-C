#include <stdio.h>
int main(){
    char palabra[50];
    while(scanf("%s",palabra)!= EOF){
            printf("%s 1\n",palabra);
        sleep(1);
    }
  return 0;
}
