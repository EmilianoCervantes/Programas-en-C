#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    char palabras[50];
    int contador = 0;
    char actual[50];
    scanf("%s",actual);
    while(scanf("%s",palabras)!=EOF){
        scanf("%s",palabras);
        if(strcmp(palabras, ",")){
        scanf("%s",palabras);
        }
        contador++;
        if(strcmp(actual, palabras)!=0){
            printf("%s , %d\n",actual, contador);
            strcpy(actual,palabras);
            contador=0;
        }
    }
    return 0;
}
