#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    system("sort");
    return 0;
}
